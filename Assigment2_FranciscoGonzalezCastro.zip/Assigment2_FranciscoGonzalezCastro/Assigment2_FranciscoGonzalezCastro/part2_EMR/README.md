# crear un cluster
mrjob create-cluster -c emr.conf

# ejecutar en el cluster
python3 mr.py -r emr s3://dataset-ngrams/data/ --cluster-id j-3RL4Y839W1TVG --region us-east-1

